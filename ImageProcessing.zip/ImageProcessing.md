
#### Procesando imagenes con Numpy


```python
import matplotlib as plt
import numpy as np
from scipy import misc
import matplotlib.pyplot as plt 
import urllib.request
from PIL import Image

#Para el fondo oscuro
plt.style.use("dark_background")
```


```python
url = "https://i.redd.it/lv76tnn52h031.png"
internet_image = Image.open(urllib.request.urlopen(url))
```


```python
# Transformamos la imagen en un array
image1 = np.array(internet_image)
image2 = np.array(internet_image)
image3 = np.array(internet_image)
```


```python
#Imprimir la imagen

plt.figure(figsize=(10,20))
plt.imshow(image1)
```




    <matplotlib.image.AxesImage at 0x7f648ead3dd8>




![png](output_4_1.png)



```python
# Veamos la forma de la imagen
print(image1.shape)
```

    (2160, 3840, 3)



```python
# Conocer el valor minimo y maximo de los valores de la imagen
print(np.amin(image1), np.amax(image2))
```

    0 255



```python
# Acceder a una fila
print("Fila completa")
print(image1[150])
print("__________________")
print("")
```

    Fila completa
    [[130  50 121]
     [130  50 121]
     [130  50 121]
     ...
     [  0   0   0]
     [  0   0   0]
     [  0   0   0]]
    __________________
    



```python
print("Columna completa")
print(image1[:, 150])
print("_______")
print("")
```

    Columna completa
    [[142  81 141]
     [135  70 134]
     [135  70 134]
     ...
     [  0   0   0]
     [  0   0   0]
     [  0   0   0]]
    _______
    



```python
print("3 colores de un pixel")
print(image1[150, 150])
```

    3 colores de un pixel
    [97 47 95]



```python
print("Imprimimos el valor de un color")
print(image1[150, 150, 0]) # color rojo
```

    Imprimimos el valor de un color
    97


### Modificando


```python
# Seleccionamos filas deseadas y columnas, un valor de color y lo llevamos a su mayor valor
image2[100:300, :, 0] = 255
image2[500:900, :, 1] = 255
image2[2000:3000, 100:1000, 2] = 255
plt.figure(figsize=(10, 20))
plt.imshow(image2)
```




    <matplotlib.image.AxesImage at 0x7f648b17e240>




![png](output_12_1.png)



```python
# Creamos un filtro que selecciona todos los pixeles menores de 150
# Esto nos creara una matriz del mismo tamaño de la imagen
# Donde exista un pixel menor de 150 pondra un True

filtro = image3 < 150
print("filtro shape: ", filtro.shape)
print("Imagen original: ", image3.shape)
```

    filtro shape:  (2160, 3840, 3)
    Imagen original:  (2160, 3840, 3)



```python
# Aplicamos el filtro a la imagen original y todos los valores en True lo mandamos a 0

image3[filtro] = 0
plt.figure(figsize=(10, 20))
plt.imshow(image3)
```




    <matplotlib.image.AxesImage at 0x7f648b206550>




![png](output_14_1.png)



```python
array_a = np.array(range(900))
array_b = np.array(range(900))
image3[array_a, array_b] = 255
plt.figure(figsize=(10, 20))
plt.imshow(image3)
```




    <matplotlib.image.AxesImage at 0x7f648b249cc0>




![png](output_15_1.png)



```python

```
